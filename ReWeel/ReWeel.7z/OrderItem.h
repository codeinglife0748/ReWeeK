#pragma once
class OrderItem
{
	int itemIndex,quantity;
};

